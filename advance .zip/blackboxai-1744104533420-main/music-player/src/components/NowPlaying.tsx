import React from 'react';
import { Song } from '../data/songs';

const NowPlaying = () => {
  return <div>Now Playing</div>;
};

export default NowPlaying;
